import java.util.Scanner;

public class Main {
	
	public static void main (String [] args) {
		
		Scanner sc = new Scanner (System.in);
		
		System.out.print("Enter your name: ");
		String name = sc.nextLine();
		
		System.out.println("Hi "+name);
		System.out.println("---------------------------------------------------------");
		System.out.println("Here's the menu: \n [1] Matcha - 25 \n [2] Wintermelon - 20 \n [3] Okinawa - 20 \n [4] Oreo - 30 \n [5] Blueberry - 40 \n [6] Red velvet - 45");
		System.out.println("---------------------------------------------------------");
		
		System.out.print("Seclect your order: ");
		String order1 = sc.nextLine();
		
		System.out.print("Seclect your order: ");
		String order2 = sc.nextLine();
		
		System.out.print("Seclect your order: ");
		String order3 = sc.nextLine();
		
		int total;
		int total1 = 0;
		int total2 = 0; 
		int total3 = 0; 
		
		if (order1.equalsIgnoreCase("1") || order1.equalsIgnoreCase("Matcha")) {
			total1 = 25;
		}
		else if (order1.equalsIgnoreCase("2") || order1.equalsIgnoreCase("Wintermelon")) {
			total1 = 20;
		}
		else if (order1.equalsIgnoreCase("3") || order1.equalsIgnoreCase("Okinawa")) {
			total1 = 20;
		}
		else if (order1.equalsIgnoreCase("4") || order1.equalsIgnoreCase("Oreo")) {
			total1 = 30;
		}
		else if (order1.equalsIgnoreCase("5") || order1.equalsIgnoreCase("Blueberry")) {
			total1 = 40;
		}
		else if (order1.equalsIgnoreCase("6") || order1.equalsIgnoreCase("Red velvet")) {
			total1 = 45;
		}
		
		if (order2.equalsIgnoreCase("1")|| order2.equalsIgnoreCase("Matcha")) {
			total2= 25;
		}
		else if (order2.equalsIgnoreCase("2")|| order2.equalsIgnoreCase("Wintermelon")) {
			total2 = 20;
		}
		else if (order2.equalsIgnoreCase("3")|| order2.equalsIgnoreCase("Okinawa")) {
			total2 = 20;
		}
		else if (order2.equalsIgnoreCase("4")|| order2.equalsIgnoreCase("Oreo")) {
			total2 = 30;
		}
		else if (order2.equalsIgnoreCase("5")|| order2.equalsIgnoreCase("Blueberry")) {
			total2 = 40;
		}
		else if (order2.equalsIgnoreCase("6")|| order2.equalsIgnoreCase("Red velvet")) {
			total2 = 45;
		}
		
		if (order3.equalsIgnoreCase("1")|| order3.equalsIgnoreCase("Matcha")) {
			total3 = 25;
		}
		else if (order3.equalsIgnoreCase("2")|| order3.equalsIgnoreCase("Wintermelon")) {
			total3 = 20;
		}
		else if (order3.equalsIgnoreCase("3")|| order3.equalsIgnoreCase("Okinawa")) {
			total3 = 20;
		}
		else if (order3.equalsIgnoreCase("4")|| order3.equalsIgnoreCase("Oreo")) {
			total3 = 30;
		}
		else if (order3.equalsIgnoreCase("5")|| order3.equalsIgnoreCase("Blueberry")) {
			total3 = 40;
		}
		else if (order3.equalsIgnoreCase("6")|| order3.equalsIgnoreCase("Red velvet")) {
			total3 = 45;
		}
		System.out.println("---------------------------------------------------------");
		
		System.out.println("The summary of your order: \n [1] "+order1+ "\n [2] "+order2+"\n [3] " +order3);
		
		total = total1+ total2 + total3;
		
		System.out.println("The total amount is: " + total);
		System.out.println("---------------------------------------------------------");
		System.out.println("List of Discount \n [1] Student - less 20 percent \n [2] PWD - less 25 percent \n [3] Regular - 0 percent");
		System.out.println("---------------------------------------------------------");
		
		System.out.println("Select your discount: ");
		String discount =sc.nextLine();
		
		System.out.println("Your money: ");
		int money =sc.nextInt();
		
		double grand = 0;
		
		if (discount.equalsIgnoreCase("1") || discount.equalsIgnoreCase("Student")) {
			grand = total * 0.20;
		}
		else if (discount.equalsIgnoreCase("2") || discount.equalsIgnoreCase("PWD")) {
			grand = total * 0.25;
		}
		else if (discount.equalsIgnoreCase("3") || discount.equalsIgnoreCase("Regular")) {
			grand = total*0;
		}
		System.out.println("---------------------------------------------------------");
		System.out.println("Your discount is: " + grand);
		System.out.println("Your grand total is : " + (total - grand ));
		System.out.println("Your money is: " + money);
		System.out.println("Your change is: " + (money - (total-grand)));
		
		
		
		
	}
}